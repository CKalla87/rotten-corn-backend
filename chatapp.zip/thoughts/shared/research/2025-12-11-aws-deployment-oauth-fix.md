---
date: 2025-12-11T01:45:40+0000
researcher: Auto
git_commit: 8214c0ce7b5bd4a77d347ab951bdf0b7130dcb2b
branch: fix/signup
repository: rotten-corn-backend
topic: "Fixing AWS deployment for development, staging, and production environments, including Google OAuth and sign in/sign up issues"
tags: [research, codebase, aws, deployment, oauth, authentication, environments]
status: complete
last_updated: 2025-12-11
last_updated_by: Auto
---

# Research: Fixing AWS Deployment and OAuth for All Environments

**Date**: 2025-12-11T01:45:40+0000
**Researcher**: Auto
**Git Commit**: 8214c0ce7b5bd4a77d347ab951bdf0b7130dcb2b
**Branch**: fix/signup
**Repository**: rotten-corn-backend

## Research Question
Create a research document fixing the deploy for AWS for development, staging and production. Make sure to fix the oauth issues for google in all 3 environments and sign in and sign up in all 3 environments.

## Summary

This research identifies critical issues with AWS deployment configuration and Google OAuth setup across development, staging, and production environments. The main problems are:

1. **Environment Detection**: The deployment script (`after_install.sh`) defaults to `staging` and doesn't properly detect the target environment from the deployment group or branch.

2. **OAuth Callback URLs**: Google OAuth callback URLs are not properly configured for all three environments. The callback URL construction logic has hardcoded fallbacks that don't account for environment-specific backend URLs.

3. **Environment Variables**: The S3 bucket structure and environment variable loading mechanism needs to properly distinguish between `develop`, `staging`, and `production` environments.

4. **Sign In/Sign Up**: While the endpoints themselves are correct, they depend on proper environment variable configuration which may be causing failures.

## Detailed Findings

### 1. AWS Deployment Configuration Issues

#### 1.1 Environment Detection in Deployment Scripts

**Location**: `scripts/after_install.sh:39-40`

The deployment script defaults to `staging` environment:

```bash
# Determine environment prefix based on deployment group or default to staging
ENV_PREFIX="${ENV_PREFIX:-staging}"
```

**Problem**: The `ENV_PREFIX` environment variable is not automatically set based on the deployment group name or GitHub branch. This means:
- Deployments to `develop` branch may load `staging` environment variables
- Deployments to `main` branch may load `staging` environment variables
- The script needs to detect the environment from the CodeDeploy deployment group name

**Solution**: The deployment group names follow the pattern `${prefix}-group` where prefix is environment-specific. The script should extract the environment from the deployment group name or use a CodeDeploy environment variable.

#### 1.2 S3 Environment File Structure

**Location**: `scripts/after_install.sh:38-43`

The script downloads environment files from S3:

```bash
ENV_BUCKET="chattapplication1-env-files"
ENV_PREFIX="${ENV_PREFIX:-staging}"
aws s3 sync "s3://${ENV_BUCKET}/${ENV_PREFIX}" .
```

**Expected S3 Structure**:
```
s3://chattapplication1-env-files/
  ├── develop/
  │   └── .env.develop (or env-file.zip)
  ├── staging/
  │   └── .env.production (or env-file.zip)
  └── production/
      └── .env.production (or env-file.zip)
```

**Issue**: The script looks for `.env.develop` for develop environment but `.env.production` for staging/production. This naming inconsistency can cause confusion.

#### 1.3 CI/CD Workflow Configuration

**Location**: `.github/workflows/ci-cd.yml`

The workflow correctly:
- Deploys to `develop` when pushing to `develop` branch (lines 61-321)
- Deploys to `staging` when pushing to `staging` branch (lines 323-519)
- Deploys to `production` when pushing to `main` branch (lines 521-717)

Each deployment job uses environment-specific secrets:
- `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`
- `AWS_REGION`
- `S3_BUCKET`
- `CODEDEPLOY_APP`
- `CODEDEPLOY_GROUP`

**Issue**: The workflow doesn't pass the environment name to the CodeDeploy deployment, so the `after_install.sh` script can't determine which environment it's deploying to.

### 2. Google OAuth Configuration Issues

#### 2.1 OAuth Callback URL Construction

**Location**: `src/shared/config/passport.config.ts:23-56` and `src/features/auth/controllers/oauth.ts:66-87`

The callback URL construction logic:

```typescript
const getCallbackURL = (provider: string): string => {
  // In development, always use localhost:5000 (backend server)
  if (config.NODE_ENV === 'development') {
    return `http://localhost:5000/api/v1/auth/${provider}/callback`;
  }
  
  // For production, check EC2_URL first (backend server URL)
  if (config.EC2_URL && !config.EC2_URL.includes('169.254.169.254') && 
      (config.EC2_URL.startsWith('http://') || config.EC2_URL.startsWith('https://'))) {
    return `${config.EC2_URL.replace(/\/$/, '')}/api/v1/auth/${provider}/callback`;
  }
  
  // Fallback: use CLIENT_URL only if it looks like a backend URL
  if (config.CLIENT_URL && !config.CLIENT_URL.includes('169.254.169.254')) {
    if (config.CLIENT_URL.includes(':5000') || config.CLIENT_URL.includes('/api')) {
      return `${config.CLIENT_URL.replace(/\/$/, '')}/api/v1/auth/${provider}/callback`;
    }
  }
  
  // Final fallback
  return `https://dev.chatappserver.space/api/v1/auth/${provider}/callback`;
};
```

**Problems**:
1. **Hardcoded fallback**: The final fallback always points to `dev.chatappserver.space`, which is incorrect for staging and production environments.
2. **Environment detection**: The logic only checks `NODE_ENV === 'development'` but doesn't distinguish between `staging` and `production`.
3. **EC2_URL configuration**: The `EC2_URL` environment variable may not be set correctly for all environments.

**Expected Callback URLs**:
- **Development**: `http://localhost:5000/api/v1/auth/google/callback` (local) or `https://api.dev.chatappserver.space/api/v1/auth/google/callback` (deployed)
- **Staging**: `https://api.staging.chatappserver.space/api/v1/auth/google/callback`
- **Production**: `https://api.chatappserver.space/api/v1/auth/google/callback`

#### 2.2 OAuth Credentials Configuration

**Location**: `src/config.ts:23-24, 48-49`

Google OAuth credentials are loaded from environment variables:
- `GOOGLE_CLIENT_ID`
- `GOOGLE_CLIENT_SECRET`

**Issue**: Each environment needs separate Google OAuth app credentials with the correct callback URLs registered in Google Cloud Console. The current code doesn't validate that credentials are set for the current environment.

#### 2.3 OAuth Redirect URI Validation

**Location**: `src/features/auth/controllers/oauth.ts:30-60`

The `validateRedirectUri` function checks against allowed origins:

```typescript
const allowedOrigins = [
  config.CLIENT_URL,
  config.EC2_URL,
  'https://dev.chatappserver.space',
  'https://chatappserver.space'
].filter(Boolean);
```

**Issue**: Missing staging URLs in the allowed origins list. Should include:
- `https://staging.chatappserver.space`
- `https://api.staging.chatappserver.space`

### 3. Sign In and Sign Up Implementation

#### 3.1 Sign In Endpoint

**Location**: `src/features/auth/controllers/signin.ts:15-55`

The sign in endpoint:
- Validates credentials using `authService.getAuthUserByUsername()`
- Compares passwords
- Generates JWT token
- Sets session cookie
- Returns user document

**Status**: The implementation is correct and doesn't have environment-specific issues. However, it depends on:
- Proper database connection (via `DATABASE_URL`)
- JWT token secret (via `JWT_TOKEN`)
- Session configuration (via `SECRET_KEY_ONE`, `SECRET_KEY_TWO`)

#### 3.2 Sign Up Endpoint

**Location**: `src/features/auth/controllers/signup.ts:25-141`

The sign up endpoint:
- Validates username/email uniqueness
- Generates avatar color
- Creates auth and user documents
- Uploads avatar image to Cloudinary
- Caches user data in Redis
- Queues database writes

**Status**: The implementation is correct. It depends on:
- Database connection
- Cloudinary configuration (`CLOUD_NAME`, `CLOUD_API_KEY`, `CLOUD_API_SECRET`)
- Redis connection (`REDIS_HOST`)

#### 3.3 Environment-Specific Configuration for Auth

**Location**: `src/setupServer.ts:45-55`

Session cookie configuration:

```typescript
cookieSession({
  name: 'session',
  keys: [config.SECRET_KEY_ONE!, config.SECRET_KEY_TWO!],
  maxAge: 24 * 7 * 360000,
  secure: config.NODE_ENV !== 'development',
  sameSite: config.NODE_ENV !== 'development' ? 'none' : 'lax',
  domain: config.NODE_ENV !== 'development' ? '.chatappserver.space' : undefined
})
```

**Issue**: The domain is hardcoded to `.chatappserver.space` for all non-development environments. This may cause issues if staging uses a different domain. Should be environment-aware.

### 4. Environment Variable Management

#### 4.1 Required Environment Variables

**Location**: `src/config.ts:7-28`

All environments need these variables:
- `DATABASE_URL` - MongoDB connection string
- `JWT_TOKEN` - JWT secret key
- `NODE_ENV` - Environment name (`development`, `staging`, `production`)
- `SECRET_KEY_ONE`, `SECRET_KEY_TWO` - Session encryption keys
- `CLIENT_URL` - Frontend URL
- `EC2_URL` - Backend API URL
- `REDIS_HOST` - Redis connection string
- `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET` - Google OAuth credentials
- `CLOUD_NAME`, `CLOUD_API_KEY`, `CLOUD_API_SECRET` - Cloudinary credentials

#### 4.2 Environment-Specific Values

**Development**:
- `NODE_ENV=development`
- `CLIENT_URL=http://localhost:3000` (or frontend dev URL)
- `EC2_URL=http://localhost:5000` (or `https://api.dev.chatappserver.space`)
- `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET` for dev OAuth app

**Staging**:
- `NODE_ENV=staging`
- `CLIENT_URL=https://staging.chatappserver.space`
- `EC2_URL=https://api.staging.chatappserver.space`
- `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET` for staging OAuth app

**Production**:
- `NODE_ENV=production`
- `CLIENT_URL=https://chatappserver.space`
- `EC2_URL=https://api.chatappserver.space`
- `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET` for production OAuth app

### 5. Terraform Infrastructure Configuration

#### 5.1 Multi-Environment Setup

**Location**: `deployment/ENVIRONMENTS.md`

The documentation describes using Terraform workspaces:
- `terraform workspace new staging`
- `terraform workspace new production`

Each workspace creates separate:
- VPC
- ALB (Application Load Balancer)
- ASG (Auto Scaling Group)
- CodeDeploy application and deployment group
- S3 bucket for artifacts

#### 5.2 CodeDeploy Configuration

**Location**: `deployment/26-code_deploy.tf`

The CodeDeploy deployment group uses:
- Deployment type: `IN_PLACE`
- Deployment config: `CodeDeployDefault.OneAtATime`
- Auto-rollback enabled on deployment failure

**Issue**: The deployment group name follows `${local.prefix}-group` pattern, which should be environment-specific. The `after_install.sh` script should extract the environment from this name.

## Code References

### Deployment Scripts
- `scripts/after_install.sh:39-40` - Environment prefix detection (defaults to staging)
- `scripts/after_install.sh:42-43` - S3 environment file download
- `scripts/after_install.sh:53-58` - Environment file selection logic
- `scripts/application_start.sh` - Application startup script

### OAuth Configuration
- `src/shared/config/passport.config.ts:23-56` - OAuth callback URL construction
- `src/features/auth/controllers/oauth.ts:66-87` - OAuth callback URL helper
- `src/features/auth/controllers/oauth.ts:30-60` - Redirect URI validation
- `src/features/auth/controllers/oauth.ts:124-127` - Google OAuth credential check

### Authentication Endpoints
- `src/features/auth/controllers/signin.ts:15-55` - Sign in implementation
- `src/features/auth/controllers/signup.ts:25-141` - Sign up implementation
- `src/features/auth/routes/authRoutes.ts:20-21` - Route registration

### Configuration
- `src/config.ts:7-54` - Environment variable loading
- `src/setupServer.ts:45-55` - Session cookie configuration
- `src/setupServer.ts:65-77` - CORS configuration

### CI/CD
- `.github/workflows/ci-cd.yml:61-321` - Develop deployment job
- `.github/workflows/ci-cd.yml:323-519` - Staging deployment job
- `.github/workflows/ci-cd.yml:521-717` - Production deployment job

## Architecture Insights

### Environment Detection Strategy

The current architecture relies on:
1. **GitHub branch** → Determines which deployment job runs
2. **GitHub environment secrets** → Provides environment-specific AWS credentials
3. **CodeDeploy deployment group** → Receives the deployment
4. **S3 bucket structure** → Stores environment-specific `.env` files

**Gap**: There's no mechanism to pass the environment name from GitHub Actions to the CodeDeploy deployment, which then needs to be detected by `after_install.sh`.

### OAuth Callback URL Strategy

The OAuth flow requires:
1. **Frontend** initiates OAuth by calling `/api/v1/auth/:provider?redirect_uri=<frontend_url>`
2. **Backend** redirects to OAuth provider with callback URL pointing to backend
3. **OAuth provider** redirects back to backend callback URL
4. **Backend** processes OAuth response and redirects to frontend with authorization code
5. **Frontend** exchanges code for token via POST `/api/v1/auth/:provider/callback`

**Issue**: The callback URL must be registered in Google Cloud Console for each environment, and the backend must construct the correct URL based on the environment.

## Recommended Fixes

### Fix 1: Environment Detection in Deployment Script

**File**: `scripts/after_install.sh`

Add logic to detect environment from deployment group name or CodeDeploy environment variable:

```bash
# Detect environment from deployment group name or CodeDeploy environment variable
if [ -n "$DEPLOYMENT_GROUP_NAME" ]; then
  # Extract environment from deployment group name (e.g., "chatapp-develop-group" -> "develop")
  ENV_PREFIX=$(echo "$DEPLOYMENT_GROUP_NAME" | sed -E 's/.*-(develop|staging|production)-group.*/\1/' || echo "")
fi

# Fallback to CodeDeploy environment variable if available
if [ -z "$ENV_PREFIX" ] && [ -n "$DEPLOYMENT_GROUP_ENVIRONMENT" ]; then
  ENV_PREFIX="$DEPLOYMENT_GROUP_ENVIRONMENT"
fi

# Final fallback: try to detect from S3 bucket structure
if [ -z "$ENV_PREFIX" ]; then
  # Check which environment folders exist in S3
  if aws s3 ls "s3://${ENV_BUCKET}/develop/" >/dev/null 2>&1; then
    ENV_PREFIX="develop"
  elif aws s3 ls "s3://${ENV_BUCKET}/staging/" >/dev/null 2>&1; then
    ENV_PREFIX="staging"
  elif aws s3 ls "s3://${ENV_BUCKET}/production/" >/dev/null 2>&1; then
    ENV_PREFIX="production"
  else
    ENV_PREFIX="staging"  # Ultimate fallback
  fi
fi

echo "[$(date)] Detected environment: ${ENV_PREFIX}"
```

### Fix 2: OAuth Callback URL Construction

**File**: `src/shared/config/passport.config.ts` and `src/features/auth/controllers/oauth.ts`

Update callback URL construction to handle all three environments:

```typescript
const getCallbackURL = (provider: string): string => {
  // In development, always use localhost:5000 (backend server)
  if (config.NODE_ENV === 'development') {
    return `http://localhost:5000/api/v1/auth/${provider}/callback`;
  }
  
  // For staging and production, check EC2_URL first (backend server URL)
  if (config.EC2_URL && !config.EC2_URL.includes('169.254.169.254') && 
      (config.EC2_URL.startsWith('http://') || config.EC2_URL.startsWith('https://'))) {
    return `${config.EC2_URL.replace(/\/$/, '')}/api/v1/auth/${provider}/callback`;
  }
  
  // Environment-specific fallbacks based on NODE_ENV
  if (config.NODE_ENV === 'staging') {
    return `https://api.staging.chatappserver.space/api/v1/auth/${provider}/callback`;
  }
  
  if (config.NODE_ENV === 'production') {
    return `https://api.chatappserver.space/api/v1/auth/${provider}/callback`;
  }
  
  // Final fallback for development (deployed)
  return `https://api.dev.chatappserver.space/api/v1/auth/${provider}/callback`;
};
```

### Fix 3: Add Staging URLs to OAuth Redirect Validation

**File**: `src/features/auth/controllers/oauth.ts:38-43`

Update allowed origins to include staging:

```typescript
const allowedOrigins = [
  config.CLIENT_URL,
  config.EC2_URL,
  'https://dev.chatappserver.space',
  'https://staging.chatappserver.space',
  'https://api.staging.chatappserver.space',
  'https://chatappserver.space',
  'https://api.chatappserver.space'
].filter(Boolean);
```

### Fix 4: Environment-Specific Session Domain

**File**: `src/setupServer.ts:45-55`

Make session domain environment-aware:

```typescript
const getSessionDomain = (): string | undefined => {
  if (config.NODE_ENV === 'development') {
    return undefined; // No domain restriction for localhost
  }
  
  // For staging and production, use appropriate domain
  if (config.NODE_ENV === 'staging') {
    return '.staging.chatappserver.space';
  }
  
  return '.chatappserver.space'; // Production
};

cookieSession({
  name: 'session',
  keys: [config.SECRET_KEY_ONE!, config.SECRET_KEY_TWO!],
  maxAge: 24 * 7 * 360000,
  secure: config.NODE_ENV !== 'development',
  sameSite: config.NODE_ENV !== 'development' ? 'none' : 'lax',
  domain: getSessionDomain()
})
```

### Fix 5: Pass Environment to CodeDeploy

**File**: `.github/workflows/ci-cd.yml`

Add environment variable to CodeDeploy deployment:

For each deployment job (develop, staging, production), add:

```yaml
- name: Create CodeDeploy deployment
  env:
    ENVIRONMENT: develop  # or staging/production
  run: |
    DEPLOYMENT_ID=$(aws deploy create-deployment \
      --application-name "$CODEDEPLOY_APP" \
      --deployment-group-name "$CODEDEPLOY_GROUP" \
      --deployment-config-name "CodeDeployDefault.AllAtOnce" \
      --s3-location bucket="$S3_BUCKET",bundleType=zip,key="${{ steps.bundle.outputs.bundle_key }}" \
      --file-exists-behavior OVERWRITE \
      --query "deploymentId" \
      --output text)
```

Note: CodeDeploy doesn't directly support environment variables in the deployment. Instead, the environment should be detected from the deployment group name in `after_install.sh`.

### Fix 6: Update S3 Environment File Structure

Ensure S3 bucket has the correct structure:

```
s3://chattapplication1-env-files/
  ├── develop/
  │   └── .env.develop (or .env)
  ├── staging/
  │   └── .env.production (or .env)
  └── production/
      └── .env.production (or .env)
```

Update `after_install.sh` to handle both naming conventions:

```bash
# Priority: .env.develop > .env.production > .env
if [ -f .env.develop ]; then
  cp .env.develop .env
  echo "[$(date)] Copied .env.develop to .env (develop environment)"
elif [ -f .env.staging ]; then
  cp .env.staging .env
  echo "[$(date)] Copied .env.staging to .env (staging environment)"
elif [ -f .env.production ]; then
  cp .env.production .env
  echo "[$(date)] Copied .env.production to .env (production environment)"
elif [ -f .env ]; then
  echo "[$(date)] .env file already exists"
else
  echo "[$(date)] ERROR: No .env file found after extraction!"
fi
```

### Fix 7: Google OAuth App Configuration

For each environment, create a separate Google OAuth app in Google Cloud Console with the correct callback URLs:

**Development**:
- Callback URL: `https://api.dev.chatappserver.space/api/v1/auth/google/callback`
- Authorized JavaScript origins: `https://api.dev.chatappserver.space`, `https://dev.chatappserver.space`

**Staging**:
- Callback URL: `https://api.staging.chatappserver.space/api/v1/auth/google/callback`
- Authorized JavaScript origins: `https://api.staging.chatappserver.space`, `https://staging.chatappserver.space`

**Production**:
- Callback URL: `https://api.chatappserver.space/api/v1/auth/google/callback`
- Authorized JavaScript origins: `https://api.chatappserver.space`, `https://chatappserver.space`

## Testing Checklist

### Deployment Testing

- [ ] Verify `develop` branch deployment loads `develop` environment variables
- [ ] Verify `staging` branch deployment loads `staging` environment variables
- [ ] Verify `main` branch deployment loads `production` environment variables
- [ ] Verify each environment connects to the correct database
- [ ] Verify each environment uses the correct Redis instance
- [ ] Verify each environment uses the correct Cloudinary account

### OAuth Testing

- [ ] Test Google OAuth from development frontend
- [ ] Test Google OAuth from staging frontend
- [ ] Test Google OAuth from production frontend
- [ ] Verify callback URLs are correctly registered in Google Cloud Console
- [ ] Verify OAuth redirect validation allows all three environments

### Sign In/Sign Up Testing

- [ ] Test sign up in development environment
- [ ] Test sign in in development environment
- [ ] Test sign up in staging environment
- [ ] Test sign in in staging environment
- [ ] Test sign up in production environment
- [ ] Test sign in in production environment
- [ ] Verify session cookies work correctly in all environments
- [ ] Verify CORS allows requests from all frontend URLs

## Open Questions

1. **CodeDeploy Environment Variables**: Is there a way to pass environment variables to CodeDeploy deployments that can be accessed by the deployment scripts? Currently, the environment must be detected from the deployment group name.

2. **S3 Environment File Naming**: Should we standardize on `.env.develop`, `.env.staging`, `.env.production` or use a single `.env` file per environment folder?

3. **Google OAuth App Strategy**: Should we use separate OAuth apps per environment, or a single app with multiple callback URLs? Separate apps provide better isolation but require more management.

4. **Session Domain Configuration**: Should staging and production share the same session domain (`.chatappserver.space`) or use separate domains? Current implementation uses shared domain which may cause cookie conflicts.

## Related Files

- `scripts/after_install.sh` - Deployment environment detection
- `scripts/application_start.sh` - Application startup
- `src/shared/config/passport.config.ts` - OAuth strategy configuration
- `src/features/auth/controllers/oauth.ts` - OAuth controller
- `src/features/auth/controllers/signin.ts` - Sign in endpoint
- `src/features/auth/controllers/signup.ts` - Sign up endpoint
- `src/config.ts` - Environment variable configuration
- `src/setupServer.ts` - Server setup and middleware
- `.github/workflows/ci-cd.yml` - CI/CD pipeline
- `deployment/ENVIRONMENTS.md` - Multi-environment setup guide


