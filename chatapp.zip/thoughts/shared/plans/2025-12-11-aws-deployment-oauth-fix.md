# AWS Deployment and OAuth Fix for All Environments Implementation Plan

## Overview

This plan implements fixes for AWS deployment configuration and Google OAuth setup across development, staging, and production environments. The main issues are: (1) deployment scripts don't properly detect the target environment, (2) OAuth callback URLs are hardcoded and don't handle all environments, (3) missing staging URLs in OAuth validation, and (4) session domain configuration is not environment-aware.

## Current State Analysis

### Key Discoveries:
- **Environment Detection**: `scripts/after_install.sh:40` defaults to `staging` and doesn't detect the actual environment from CodeDeploy
- **OAuth Callback URLs**: `src/shared/config/passport.config.ts:53` and `src/features/auth/controllers/oauth.ts:86` have hardcoded fallback to `dev.chatappserver.space` for all environments
- **Missing Staging URLs**: `src/features/auth/controllers/oauth.ts:38-43` doesn't include staging URLs in allowed origins
- **Session Domain**: `src/setupServer.ts:53` hardcodes `.chatappserver.space` for all non-dev environments
- **CodeDeploy Environment Variables**: CodeDeploy automatically provides `DEPLOYMENT_GROUP_NAME` environment variable to deployment hooks (confirmed via AWS documentation)

### Current Implementation:
- Deployment group names follow pattern: `${prefix}-group` where prefix is environment-specific (e.g., `chatapp-develop-group`, `chatapp-staging-group`, `chatapp-production-group`)
- S3 bucket structure: `s3://chattapplication1-env-files/{develop|staging|production}/`
- Environment files may be named `.env.develop`, `.env.staging`, `.env.production`, or just `.env`
- OAuth callback URL construction only checks `NODE_ENV === 'development'` but doesn't distinguish staging vs production

## Desired End State

After this plan is complete:

1. **Environment Detection**: Deployment scripts automatically detect the correct environment (develop/staging/production) from CodeDeploy's `DEPLOYMENT_GROUP_NAME` and load the appropriate environment variables from S3
2. **OAuth Callback URLs**: OAuth callback URLs are correctly constructed for all three environments based on `NODE_ENV` and `EC2_URL`
3. **OAuth Validation**: All three environments' frontend and backend URLs are included in OAuth redirect URI validation
4. **Session Configuration**: Session cookies use environment-appropriate domains (no domain for dev, `.staging.chatappserver.space` for staging, `.chatappserver.space` for production)
5. **Sign In/Sign Up**: Both endpoints work correctly in all environments once proper environment variables are loaded

### Verification:
- Deploy to `develop` branch → loads `develop` environment variables, uses dev OAuth callback URLs
- Deploy to `staging` branch → loads `staging` environment variables, uses staging OAuth callback URLs  
- Deploy to `main` branch → loads `production` environment variables, uses production OAuth callback URLs
- Google OAuth works from all three frontend environments
- Sign in and sign up work in all three environments

## What We're NOT Doing

- Creating new Google OAuth apps (this must be done manually in Google Cloud Console - documented in plan)
- Modifying Terraform infrastructure (infrastructure is already set up correctly)
- Changing the CI/CD workflow structure (only adding environment detection logic)
- Modifying sign in/sign up endpoint implementations (they're already correct, just need proper env vars)

## Implementation Approach

We'll fix these issues in phases:
1. **Phase 1**: Fix environment detection in deployment scripts
2. **Phase 2**: Fix OAuth callback URL construction
3. **Phase 3**: Add staging URLs to OAuth validation and fix session domain
4. **Phase 4**: Update environment file handling to support all naming conventions

Each phase is independent and can be tested separately, but they should be implemented in order for proper testing.

## Phase 1: Fix Environment Detection in Deployment Scripts

### Overview
Update `scripts/after_install.sh` to automatically detect the environment from CodeDeploy's `DEPLOYMENT_GROUP_NAME` environment variable and load the correct environment files from S3.

### Changes Required:

#### 1. Environment Detection Logic
**File**: `scripts/after_install.sh`
**Location**: Replace lines 38-40

**Current code**:
```bash
ENV_BUCKET="chattapplication1-env-files"
# Determine environment prefix based on deployment group or default to staging
ENV_PREFIX="${ENV_PREFIX:-staging}"
```

**New code**:
```bash
ENV_BUCKET="chattapplication1-env-files"

# Detect environment from CodeDeploy deployment group name
# CodeDeploy automatically provides DEPLOYMENT_GROUP_NAME environment variable
# Deployment group names follow pattern: ${prefix}-group
# Examples: chatapp-develop-group, chatapp-staging-group, chatapp-production-group
ENV_PREFIX=""

if [ -n "$DEPLOYMENT_GROUP_NAME" ]; then
  # Extract environment from deployment group name
  # Pattern: extract "develop", "staging", or "production" from group name
  if echo "$DEPLOYMENT_GROUP_NAME" | grep -qE "-(develop|staging|production)-group"; then
    ENV_PREFIX=$(echo "$DEPLOYMENT_GROUP_NAME" | sed -E 's/.*-(develop|staging|production)-group.*/\1/')
    echo "[$(date)] Detected environment from DEPLOYMENT_GROUP_NAME: ${ENV_PREFIX}"
  fi
fi

# Fallback: try to detect from S3 bucket structure
if [ -z "$ENV_PREFIX" ]; then
  echo "[$(date)] DEPLOYMENT_GROUP_NAME not available or doesn't match pattern, checking S3..."
  for env in develop staging production; do
    if aws s3 ls "s3://${ENV_BUCKET}/${env}/" >/dev/null 2>&1; then
      # Check if this is the only environment folder (likely the correct one)
      ENV_PREFIX="$env"
      echo "[$(date)] Found environment folder in S3: ${env}"
      break
    fi
  done
fi

# Ultimate fallback: default to staging (but log warning)
if [ -z "$ENV_PREFIX" ]; then
  ENV_PREFIX="staging"
  echo "[$(date)] WARNING: Could not detect environment, defaulting to staging"
  echo "[$(date)] DEPLOYMENT_GROUP_NAME was: ${DEPLOYMENT_GROUP_NAME:-not set}"
fi

echo "[$(date)] Using environment: ${ENV_PREFIX}"
```

#### 2. Environment File Selection Logic
**File**: `scripts/after_install.sh`
**Location**: Replace lines 51-63

**Current code**:
```bash
# Priority: .env.develop > .env.production > .env
# For dev environment, prefer .env.develop
if [ -f .env.develop ]; then
  cp .env.develop .env
  echo "[$(date)] Copied .env.develop to .env (dev environment)"
elif [ -f .env.production ]; then
  cp .env.production .env
  echo "[$(date)] Copied .env.production to .env"
elif [ -f .env ]; then
  echo "[$(date)] .env file already exists"
else
  echo "[$(date)] ERROR: No .env, .env.production, or .env.develop file found after extraction!"
fi
```

**New code**:
```bash
# Select environment file based on detected environment
# Priority: .env.{ENV_PREFIX} > .env.production > .env
ENV_FILE_COPIED=false

if [ -f ".env.${ENV_PREFIX}" ]; then
  cp ".env.${ENV_PREFIX}" .env
  echo "[$(date)] Copied .env.${ENV_PREFIX} to .env (${ENV_PREFIX} environment)"
  ENV_FILE_COPIED=true
elif [ -f .env.production ] && [ "$ENV_PREFIX" = "production" ]; then
  cp .env.production .env
  echo "[$(date)] Copied .env.production to .env (production environment)"
  ENV_FILE_COPIED=true
elif [ -f .env.staging ] && [ "$ENV_PREFIX" = "staging" ]; then
  cp .env.staging .env
  echo "[$(date)] Copied .env.staging to .env (staging environment)"
  ENV_FILE_COPIED=true
elif [ -f .env.develop ] && [ "$ENV_PREFIX" = "develop" ]; then
  cp .env.develop .env
  echo "[$(date)] Copied .env.develop to .env (develop environment)"
  ENV_FILE_COPIED=true
elif [ -f .env ]; then
  echo "[$(date)] Using existing .env file (no environment-specific file found)"
  ENV_FILE_COPIED=true
fi

if [ "$ENV_FILE_COPIED" = false ]; then
  echo "[$(date)] ERROR: No .env file found for environment ${ENV_PREFIX}!"
  echo "[$(date)] Expected one of: .env.${ENV_PREFIX}, .env.production, .env.staging, .env.develop, or .env"
  exit 1
fi
```

### Success Criteria:

#### Automated Verification:
- [x] Script syntax is valid: `bash -n scripts/after_install.sh`
- [x] No linting errors in shell scripts
- [x] Environment detection logic extracts correct environment from test deployment group names:
  - `chatapp-develop-group` → `develop`
  - `chatapp-staging-group` → `staging`
  - `chatapp-production-group` → `production`

#### Manual Verification:
- [ ] Deploy to `develop` branch and verify logs show: "Detected environment from DEPLOYMENT_GROUP_NAME: develop"
- [ ] Deploy to `staging` branch and verify logs show: "Detected environment from DEPLOYMENT_GROUP_NAME: staging"
- [ ] Deploy to `main` branch and verify logs show: "Detected environment from DEPLOYMENT_GROUP_NAME: production"
- [ ] Verify correct `.env` file is loaded for each environment (check that `NODE_ENV` matches expected value)
- [ ] Verify application starts successfully with correct environment variables

**Implementation Note**: After completing this phase and all automated verification passes, pause here for manual confirmation from the human that the manual testing was successful before proceeding to the next phase.

---

## Phase 2: Fix OAuth Callback URL Construction

### Overview
Update OAuth callback URL construction logic in both `passport.config.ts` and `oauth.ts` to properly handle all three environments (development, staging, production) with correct fallbacks.

### Changes Required:

#### 1. Update Passport Config Callback URL Helper
**File**: `src/shared/config/passport.config.ts`
**Location**: Replace lines 23-56

**Current code**: (see research document for full current implementation)

**New code**:
```typescript
// Helper function to construct callback URL consistently
// NOTE: Callback URL must point to the BACKEND server, not the frontend CLIENT_URL
const getCallbackURL = (provider: string): string => {
  // In development, always use localhost:5000 (backend server)
  if (config.NODE_ENV === 'development') {
    const url = `http://localhost:5000/api/v1/auth/${provider}/callback`;
    log.info(`${provider} OAuth callback URL (development): ${url}`);
    return url;
  }
  
  // For staging and production, check EC2_URL first (backend server URL)
  if (config.EC2_URL && !config.EC2_URL.includes('169.254.169.254') && 
      (config.EC2_URL.startsWith('http://') || config.EC2_URL.startsWith('https://'))) {
    const baseUrl = config.EC2_URL.replace(/\/$/, '');
    const url = `${baseUrl}/api/v1/auth/${provider}/callback`;
    log.info(`${provider} OAuth callback URL (EC2_URL): ${url}`);
    return url;
  }
  
  // Environment-specific fallbacks based on NODE_ENV
  if (config.NODE_ENV === 'staging') {
    const url = `https://api.staging.chatappserver.space/api/v1/auth/${provider}/callback`;
    log.info(`${provider} OAuth callback URL (staging fallback): ${url}`);
    return url;
  }
  
  if (config.NODE_ENV === 'production') {
    const url = `https://api.chatappserver.space/api/v1/auth/${provider}/callback`;
    log.info(`${provider} OAuth callback URL (production fallback): ${url}`);
    return url;
  }
  
  // Final fallback for development (deployed)
  const url = `https://api.dev.chatappserver.space/api/v1/auth/${provider}/callback`;
  log.warn(`${provider} OAuth callback URL (final fallback): ${url} - Make sure this matches your OAuth provider settings!`);
  return url;
};
```

#### 2. Update OAuth Controller Callback URL Helper
**File**: `src/features/auth/controllers/oauth.ts`
**Location**: Replace lines 66-87

**Current code**: (see research document for full current implementation)

**New code**:
```typescript
  /**
   * Get the expected callback URL for a provider
   * NOTE: Callback URL must point to the BACKEND server, not the frontend CLIENT_URL
   */
  private getExpectedCallbackUrl(provider: string): string {
    // In development, always use localhost:5000 (backend server)
    if (config.NODE_ENV === 'development') {
      return `http://localhost:5000/api/v1/auth/${provider}/callback`;
    }
    
    // For staging and production, check EC2_URL first (backend server URL)
    if (config.EC2_URL && !config.EC2_URL.includes('169.254.169.254') &&
        (config.EC2_URL.startsWith('http://') || config.EC2_URL.startsWith('https://'))) {
      return `${config.EC2_URL.replace(/\/$/, '')}/api/v1/auth/${provider}/callback`;
    }
    
    // Environment-specific fallbacks based on NODE_ENV
    if (config.NODE_ENV === 'staging') {
      return `https://api.staging.chatappserver.space/api/v1/auth/${provider}/callback`;
    }
    
    if (config.NODE_ENV === 'production') {
      return `https://api.chatappserver.space/api/v1/auth/${provider}/callback`;
    }
    
    // Final fallback for development (deployed)
    return `https://api.dev.chatappserver.space/api/v1/auth/${provider}/callback`;
  }
```

### Success Criteria:

#### Automated Verification:
- [x] TypeScript compiles without errors: `npm run build`
- [x] No linting errors: `npm run lint:check` (only pre-existing warnings)
- [x] Unit tests pass: `npm run test` (existing tests continue to pass)
- [x] Type checking passes: `tsc --noEmit` (verified via build)

#### Manual Verification:
- [ ] Start application with `NODE_ENV=development` and verify callback URL logs show: `http://localhost:5000/api/v1/auth/google/callback`
- [ ] Start application with `NODE_ENV=staging` and verify callback URL logs show staging URL (either from `EC2_URL` or fallback)
- [ ] Start application with `NODE_ENV=production` and verify callback URL logs show production URL (either from `EC2_URL` or fallback)
- [ ] Verify OAuth health check endpoint (`/api/v1/auth/health`) returns correct callback URLs for each environment
- [ ] Test Google OAuth flow in each environment and verify it uses the correct callback URL

**Implementation Note**: After completing this phase and all automated verification passes, pause here for manual confirmation from the human that the manual testing was successful before proceeding to the next phase.

---

## Phase 3: Add Staging URLs to OAuth Validation and Fix Session Domain

### Overview
Update OAuth redirect URI validation to include staging URLs and make session cookie domain environment-aware.

### Changes Required:

#### 1. Add Staging URLs to OAuth Redirect Validation
**File**: `src/features/auth/controllers/oauth.ts`
**Location**: Replace lines 38-43

**Current code**:
```typescript
const allowedOrigins = [
  config.CLIENT_URL,
  config.EC2_URL,
  'https://dev.chatappserver.space',
  'https://chatappserver.space'
].filter(Boolean);
```

**New code**:
```typescript
const allowedOrigins = [
  config.CLIENT_URL,
  config.EC2_URL,
  'https://dev.chatappserver.space',
  'https://api.dev.chatappserver.space',
  'https://staging.chatappserver.space',
  'https://api.staging.chatappserver.space',
  'https://chatappserver.space',
  'https://api.chatappserver.space'
].filter(Boolean);
```

#### 2. Make Session Domain Environment-Aware
**File**: `src/setupServer.ts`
**Location**: Replace lines 45-55

**Current code**:
```typescript
cookieSession({
  name: 'session',
  keys: [config.SECRET_KEY_ONE!, config.SECRET_KEY_TWO!],
  maxAge: 24 * 7 * 360000,
  secure: config.NODE_ENV !== 'development',
  sameSite: config.NODE_ENV !== 'development' ? 'none' : 'lax',
  domain: config.NODE_ENV !== 'development' ? '.chatappserver.space' : undefined
})
```

**New code**:
```typescript
// Helper function to get session domain based on environment
const getSessionDomain = (): string | undefined => {
  if (config.NODE_ENV === 'development') {
    return undefined; // No domain restriction for localhost
  }
  
  // For staging, use staging-specific domain
  if (config.NODE_ENV === 'staging') {
    return '.staging.chatappserver.space';
  }
  
  // For production, use production domain
  return '.chatappserver.space';
};

cookieSession({
  name: 'session',
  keys: [config.SECRET_KEY_ONE!, config.SECRET_KEY_TWO!],
  maxAge: 24 * 7 * 360000,
  secure: config.NODE_ENV !== 'development',
  sameSite: config.NODE_ENV !== 'development' ? 'none' : 'lax',
  domain: getSessionDomain()
})
```

### Success Criteria:

#### Automated Verification:
- [x] TypeScript compiles without errors: `npm run build`
- [x] No linting errors: `npm run lint:check` (only pre-existing warnings)
- [x] Unit tests pass: `npm run test` (existing tests continue to pass)
- [x] Type checking passes: `tsc --noEmit` (verified via build)

#### Manual Verification:
- [ ] Test OAuth redirect from staging frontend (`https://staging.chatappserver.space`) and verify it's allowed
- [ ] Test OAuth redirect from production frontend (`https://chatappserver.space`) and verify it's allowed
- [ ] Test OAuth redirect from development frontend and verify it's allowed
- [ ] Verify session cookies are set with correct domain:
  - Development: no domain (localhost)
  - Staging: `.staging.chatappserver.space`
  - Production: `.chatappserver.space`
- [ ] Test sign in and sign up in all three environments and verify session cookies work correctly

**Implementation Note**: After completing this phase and all automated verification passes, pause here for manual confirmation from the human that the manual testing was successful before proceeding to the next phase.

---

## Phase 4: Documentation and Google OAuth App Configuration

### Overview
Document the required Google OAuth app configuration for each environment. This phase doesn't involve code changes but ensures the OAuth apps are properly configured.

### Changes Required:

#### 1. Create OAuth Configuration Documentation
**File**: `docs/oauth-setup.md` (new file)

Create a new documentation file with instructions for setting up Google OAuth apps for each environment:

```markdown
# Google OAuth Configuration Guide

This document describes how to configure Google OAuth apps for each environment.

## Required OAuth Apps

Each environment requires a separate Google OAuth app in Google Cloud Console with the correct callback URLs registered.

### Development Environment

1. Create a new OAuth 2.0 Client ID in Google Cloud Console
2. Configure the following:
   - **Name**: Rotten Corn Backend - Development
   - **Authorized JavaScript origins**:
     - `https://api.dev.chatappserver.space`
     - `https://dev.chatappserver.space`
   - **Authorized redirect URIs**:
     - `https://api.dev.chatappserver.space/api/v1/auth/google/callback`
   - **Application type**: Web application

3. Copy the Client ID and Client Secret to the development environment variables:
   - `GOOGLE_CLIENT_ID`
   - `GOOGLE_CLIENT_SECRET`

### Staging Environment

1. Create a new OAuth 2.0 Client ID in Google Cloud Console
2. Configure the following:
   - **Name**: Rotten Corn Backend - Staging
   - **Authorized JavaScript origins**:
     - `https://api.staging.chatappserver.space`
     - `https://staging.chatappserver.space`
   - **Authorized redirect URIs**:
     - `https://api.staging.chatappserver.space/api/v1/auth/google/callback`
   - **Application type**: Web application

3. Copy the Client ID and Client Secret to the staging environment variables in S3:
   - `GOOGLE_CLIENT_ID`
   - `GOOGLE_CLIENT_SECRET`

### Production Environment

1. Create a new OAuth 2.0 Client ID in Google Cloud Console
2. Configure the following:
   - **Name**: Rotten Corn Backend - Production
   - **Authorized JavaScript origins**:
     - `https://api.chatappserver.space`
     - `https://chatappserver.space`
   - **Authorized redirect URIs**:
     - `https://api.chatappserver.space/api/v1/auth/google/callback`
   - **Application type**: Web application

3. Copy the Client ID and Client Secret to the production environment variables in S3:
   - `GOOGLE_CLIENT_ID`
   - `GOOGLE_CLIENT_SECRET`

## Verification

After configuring OAuth apps, verify:

1. Each environment's OAuth health check endpoint returns the correct callback URL:
   - Development: `GET https://api.dev.chatappserver.space/api/v1/auth/health`
   - Staging: `GET https://api.staging.chatappserver.space/api/v1/auth/health`
   - Production: `GET https://api.chatappserver.space/api/v1/auth/health`

2. Test OAuth flow from each frontend:
   - Initiate OAuth from frontend
   - Verify redirect to Google
   - Verify callback URL matches registered URL
   - Verify successful authentication
```

### Success Criteria:

#### Automated Verification:
- [x] Documentation file exists: `docs/oauth-setup.md`
- [x] Documentation is properly formatted (markdown linting passes if available)

#### Manual Verification:
- [ ] Google OAuth apps are created for all three environments in Google Cloud Console
- [ ] Callback URLs are correctly registered for each environment
- [ ] Environment variables (`GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`) are set in S3 for each environment
- [ ] OAuth health check endpoints return correct callback URLs
- [ ] Google OAuth flow works end-to-end in all three environments

**Implementation Note**: This phase requires manual configuration in Google Cloud Console. After completing the documentation, the human should configure the OAuth apps and verify they work.

---

## Testing Strategy

### Unit Tests

No new unit tests are required as these changes are primarily configuration and environment detection logic. Existing tests should continue to pass.

### Integration Tests

1. **Environment Detection Test** (manual):
   - Deploy to each branch and verify correct environment is detected
   - Check deployment logs for environment detection messages

2. **OAuth Callback URL Test**:
   - Call OAuth health check endpoint in each environment
   - Verify returned callback URLs match expected values

3. **OAuth Flow Test** (manual):
   - Test complete OAuth flow from each frontend environment
   - Verify successful authentication and session creation

### Manual Testing Steps

1. **Deployment Testing**:
   - Push to `develop` branch → verify deployment loads `develop` environment
   - Push to `staging` branch → verify deployment loads `staging` environment
   - Push to `main` branch → verify deployment loads `production` environment
   - Check deployment logs for correct environment detection

2. **OAuth Testing**:
   - Test Google OAuth from `https://dev.chatappserver.space`
   - Test Google OAuth from `https://staging.chatappserver.space`
   - Test Google OAuth from `https://chatappserver.space`
   - Verify callback URLs are correct in each case

3. **Sign In/Sign Up Testing**:
   - Test sign up in development environment
   - Test sign in in development environment
   - Test sign up in staging environment
   - Test sign in in staging environment
   - Test sign up in production environment
   - Test sign in in production environment
   - Verify session cookies are set correctly in each environment

## Performance Considerations

No performance impact expected. These changes are primarily configuration and environment detection logic that runs once during deployment or application startup.

## Migration Notes

### Existing Deployments

- Existing deployments will continue to work but will default to `staging` environment until Phase 1 is deployed
- After Phase 1 is deployed, existing deployments will automatically detect the correct environment
- No data migration required

### Environment Variables

- Ensure S3 bucket `chattapplication1-env-files` has the correct structure:
  ```
  s3://chattapplication1-env-files/
    ├── develop/
    │   └── .env.develop (or .env)
    ├── staging/
    │   └── .env.staging (or .env.production, or .env)
    └── production/
        └── .env.production (or .env)
  ```

### Google OAuth Apps

- Must be manually created in Google Cloud Console (see Phase 4 documentation)
- Each environment needs separate OAuth app credentials
- Update environment variables in S3 after creating OAuth apps

## Rollback Plan

If issues occur:

1. **Phase 1 Rollback**: Revert `scripts/after_install.sh` to previous version (defaults to staging)
2. **Phase 2 Rollback**: Revert OAuth callback URL changes in `passport.config.ts` and `oauth.ts`
3. **Phase 3 Rollback**: Revert session domain and OAuth validation changes
4. **Phase 4 Rollback**: No code changes to rollback, but OAuth apps can be disabled in Google Cloud Console

Each phase can be rolled back independently without affecting others.

## References

- Original research: `thoughts/shared/research/2025-12-11-aws-deployment-oauth-fix.md`
- CodeDeploy environment variables: [AWS Documentation](https://docs.aws.amazon.com/codedeploy/latest/userguide/reference-appspec-file-structure-hooks.html)
- Deployment scripts: `scripts/after_install.sh`, `scripts/application_start.sh`
- OAuth configuration: `src/shared/config/passport.config.ts`, `src/features/auth/controllers/oauth.ts`
- Session configuration: `src/setupServer.ts`
- CI/CD workflow: `.github/workflows/ci-cd.yml`


