import { CommentsModel } from '@comment/models/comment.schema';
import { ICommentDocument, ICommentJob, ICommentNameList, IQueryComment } from './../../../features/comments/interfaces/comment.interface';
import { UserCache } from '@service/redis/user.cache';
import { IPostDocument } from '@post/interfaces/post.interface';
import { PostModel } from '@post/models/post.schema';
import mongoose, { Query } from 'mongoose';
import { IUserDocument } from '@user/interfaces/user.interface';
import { INotificationDocument, INotificationTemplate } from '@notification/interfaces/notification.interface';
import { NotificationModel } from '@notification/models/notification.schema';
import { socketIONotificationObject } from '@socket/notification';
import { notificationTemplate } from '@service/emails/templates/notifications/notification-template';
import { emailQueue } from '@service/queues/email.queue';

const userCache: UserCache = new UserCache();

class CommentService {
  public async addCommentToDB(commentData: ICommentJob): Promise<void> {
    const { postId, userTo, userFrom, username, comment } = commentData;
    const commentPromise: Promise<ICommentDocument> = CommentsModel.create(comment);
    const postPromise: Query<IPostDocument, IPostDocument> = PostModel.findOneAndUpdate(
      { _id: postId },
      { $inc: { commentsCount: 1 } },
      { new: true }
    ) as Query<IPostDocument, IPostDocument>;
    const userPromise: Promise<IUserDocument> = userCache.getUserFromCache(userTo) as Promise<IUserDocument>;
    const response = (await Promise.all([commentPromise, postPromise, userPromise])) as [ICommentDocument, IPostDocument, IUserDocument];

    if (response[2]?.notifications?.comments && userFrom !== userTo) {
      const notificationModel: INotificationDocument = new NotificationModel();
      const notifications: INotificationDocument[] = await notificationModel.insertNotification({
        userFrom,
        userTo,
        message: `${username} commented on your post.`,
        notificationType: 'comment',
        entityId: new mongoose.Types.ObjectId(postId),
        createdItemId: new mongoose.Types.ObjectId(response[0]._id),
        createdAt: new Date(),
        comment: comment.comment,
        post: response[1]?.post ?? '',
        imgId: response[1]?.imgId ?? '',
        imgVersion: response[1]?.imgVersion ?? '',
        gifUrl: response[1]?.gifUrl ?? '',
        reaction: ''
      });
      socketIONotificationObject?.emit('insert notification', notifications, { userTo });

      const templateParams: INotificationTemplate = {
        username: response[2]?.username ?? 'User',
        message: `${username} commented on your post.`,
        header: 'Comment Notification'
      };
      const recipientEmail = response[2]?.email;
      if (recipientEmail) {
        const template: string = notificationTemplate.notificationMessageTemplate(templateParams);
        emailQueue.addEmailJob('commentsEmail', { receiverEmail: recipientEmail, template, subject: 'Post notification' });
      }
    }
  }

  public async getPostComments(query: IQueryComment, sort: Record<string, 1 | -1>): Promise<ICommentDocument[]> {
    const comments: ICommentDocument[] = await CommentsModel.aggregate([{ $match: { query } }, { $sort: sort }]);
    return comments;
  }

  public async getPostCommentNames(query: IQueryComment, sort: Record<string, 1 | -1>): Promise<ICommentNameList[]> {
    const commentsNameList: ICommentNameList[] = await CommentsModel.aggregate([
      { $match: { query } },
      { $sort: sort },
      { $group: { _id: null, names: { $addToSet: '$username' }, count: { $sum: 1 } } },
      { $project: { _id: 0 } }
    ]);
    return commentsNameList;
  }
}

export const commentService: CommentService = new CommentService();
