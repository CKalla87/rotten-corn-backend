import { UserCache } from './../../../shared/services/redis/user.cache';
import { IUserDocument } from './../../user/interfaces/user.interface';
import HTTP_STATUS from 'http-status-codes';
import { UploadApiResponse } from 'cloudinary';
import { BadRequestError } from './../../../shared/globals/helpers/error-handler';
import { authService } from './../../../shared/services/db/auth.service';
import { IAuthDocument, ISignUpData } from './../interfaces/auth.interface';
import { ObjectId } from 'mongodb';
import { Request, Response } from 'express';
import { joiValidation } from '@root/shared/decorators/joi-validation.decorators';
import { signupSchema } from '@auth/schemes/signup';
import { Helpers } from '@global/helpers/helpers';
import { uploads, getCloudinaryImageUrl } from '@global/helpers/cloudinary-upload';
import { omit } from 'lodash';
import JWT from 'jsonwebtoken';
import { authQueue } from '@service/queues/auth.queue';
import { userQueue } from '@service/queues/user.queue';
import { config } from '@root/config';
import { generateAvatarColor } from '@global/helpers/oauth-helpers';

const userCache: UserCache = new UserCache();

export class SignUp {
  @joiValidation(signupSchema)
  public async create(req: Request, res: Response): Promise<void> {
    const { username, email, password, avatarColor, avatarImage } = req.body;
    const checkIfUserExists: IAuthDocument = await authService.getUserByUsernameOrEmail(username, email);
    if (checkIfUserExists) {
      const normalizedUsername = Helpers.normalizeUsername(username);
      const normalizedEmail = Helpers.lowerCase(email);

      // Check which field caused the conflict
      if (checkIfUserExists.username?.toLowerCase() === normalizedUsername) {
        throw new BadRequestError('Username is already taken');
      }
      if (checkIfUserExists.email?.toLowerCase() === normalizedEmail) {
        throw new BadRequestError('Email is already registered');
      }
      // Fallback (shouldn't happen, but just in case)
      throw new BadRequestError('Username or email is already taken');
    }

    // Generate color if not provided
    const finalAvatarColor = avatarColor || generateAvatarColor();

    const authObjectId: ObjectId = new ObjectId();
    const userObjectId: ObjectId = new ObjectId();
    const uId = `${Helpers.generateRandomIntegers(12)}`;
    const authData: IAuthDocument = SignUp.prototype.signupData({
      _id: authObjectId,
      uId,
      username,
      email,
      password,
      avatarColor: finalAvatarColor
    });

    const result: UploadApiResponse = (await uploads(avatarImage, `${userObjectId}`, true, true)) as UploadApiResponse;
    if (!result?.public_id) {
      throw new BadRequestError('File upload: Eerror occured. Try again.');
    }

    // Add to redis cache
    const userDataForCache: IUserDocument = SignUp.prototype.userData(authData, userObjectId);
    userDataForCache.profilePicture = getCloudinaryImageUrl(result.public_id, result.version);
    await userCache.saveUserToCache(`${userObjectId}`, uId, userDataForCache);

    // Add to database
    const userResult = omit(userDataForCache, ['uId', 'username', 'email', 'avatarColor', 'password']);
    authQueue.addAuthUserJob('addAuthUserToDB', { value: authData });
    userQueue.addUserJob('addUserToDB', { value: userResult });

    const userJwt: string = SignUp.prototype.signToken(authData, userObjectId);
    
    // Set session - DO NOT replace req.session, only modify it
    // cookie-session uses a Proxy to detect changes, so we must modify the existing object
    if (!req.session) {
      (req as any).session = {};
    }
    (req.session as any).jwt = userJwt;
    
    // ALSO set a regular cookie with the JWT as a fallback
    // Deployed environments are: 'develop', 'staging', 'production'
    // Local development is: 'development' (or undefined) with no EC2_URL or CLIENT_URL with chatappserver.space
    const isLocalDev = config.NODE_ENV === 'development' &&
                       !config.EC2_URL &&
                       !config.CLIENT_URL?.includes('chatappserver.space');
    
    const cookieOptions: any = {
      maxAge: 24 * 7 * 3600000,
      httpOnly: true,
      secure: !isLocalDev,
      sameSite: isLocalDev ? 'lax' : 'none',
      path: '/'
    };
    
    if (!isLocalDev) {
      cookieOptions.domain = '.chatappserver.space';
    }
    
    res.cookie('jwt', userJwt, cookieOptions);

    res.status(HTTP_STATUS.CREATED).json({ message: 'User created successfully', user: userDataForCache, token: userJwt });
  }

  private signToken(data: IAuthDocument, userObjectId: ObjectId): string {
    return JWT.sign(
      {
        userId: userObjectId,
        uId: data.uId,
        email: data.email,
        username: data.username,
        avatarColor: data.avatarColor
      },
      config.JWT_TOKEN!
    );
  }

  private signupData(data: ISignUpData): IAuthDocument {
    const { _id, username, email, uId, password, avatarColor } = data;
    return {
      _id,
      uId,
      username: Helpers.normalizeUsername(username),
      email: Helpers.lowerCase(email),
      password,
      avatarColor,
      createdAt: new Date()
    } as IAuthDocument;
  }

  private userData(data: IAuthDocument, userObjectId: ObjectId): IUserDocument {
    const { _id, username, email, uId, password, avatarColor } = data;
    return {
      _id: userObjectId,
      authId: _id,
      uId,
      username: Helpers.normalizeUsername(username),
      email,
      password,
      avatarColor,
      profilePicture: '',
      blocked: [],
      blockedBy: [],
      work: '',
      location: '',
      school: '',
      quote: '',
      bgImageVersion: '',
      bgImageId: '',
      followersCount: 0,
      followingCount: 0,
      postsCount: 0,
      notifications: {
        messages: true,
        reactions: true,
        comments: true,
        follows: true
      },
      social: {
        facebook: '',
        instagram: '',
        twitter: '',
        youtube: ''
      }
    } as unknown as IUserDocument;
  }
}
