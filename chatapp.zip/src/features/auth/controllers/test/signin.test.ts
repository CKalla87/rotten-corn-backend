/* eslint-disable @typescript-eslint/no-explicit-any */
import { authMockRequest, authMockResponse } from '@root/mocks/auth.mock';
import { Request, Response } from 'express';
import { CustomError } from '@global/helpers/error-handler';
import { SignIn } from '@auth/controllers/signin';
import { Helpers } from '@global/helpers/helpers';
import { authService } from '@service/db/auth.service';

const USERNAME = 'Manny';
const PASSWORD = 'Password123!';
const WRONG_USERNAME = 'ab';
const WRONG_PASSWORD = 'Pass1!';
const LONG_PASSWORD = 'P'.repeat(129) + '1!';
const LONG_USERNAME = 'a'.repeat(31);

jest.useFakeTimers();
jest.mock('@service/queues/base.queue');

describe('SignIn', () => {
  beforeEach(() => {
    jest.restoreAllMocks();
  });

  afterEach(() => {
    jest.clearAllMocks();
    jest.clearAllTimers();
  });

  it('should throw an error if username is not available', () => {
    const req: Request = authMockRequest({}, { username: '', password: PASSWORD }) as Request;
    const res: Response = authMockResponse();
    SignIn.prototype.read(req, res).catch((error: CustomError) => {
      expect(error.statusCode).toEqual(400);
      expect(error.serializeErrors().message).toContain('Username is a required field');
    });
  });

  it('should throw an error if username length is less than minimum length', () => {
    const req: Request = authMockRequest({}, { username: WRONG_USERNAME, password: PASSWORD }) as Request;
    const res: Response = authMockResponse();
    SignIn.prototype.read(req, res).catch((error: CustomError) => {
      expect(error.statusCode).toEqual(400);
      expect(error.serializeErrors().message).toContain('Username must be at least 3 characters');
    });
  });

  it('should throw an error if username length is greater than maximum length', () => {
    const req: Request = authMockRequest({}, { username: LONG_USERNAME, password: PASSWORD }) as Request;
    const res: Response = authMockResponse();
    SignIn.prototype.read(req, res).catch((error: CustomError) => {
      expect(error.statusCode).toEqual(400);
      expect(error.serializeErrors().message).toContain('Username must be no more than 30 characters');
    });
  });

  it('should reject username with special characters', () => {
    const req: Request = authMockRequest({}, { username: 'user@name', password: PASSWORD }) as Request;
    const res: Response = authMockResponse();
    SignIn.prototype.read(req, res).catch((error: CustomError) => {
      expect(error.statusCode).toEqual(400);
      expect(error.serializeErrors().message).toContain('Username can only contain letters, numbers, underscores, and hyphens');
    });
  });

  it('should throw an error if password is not available', () => {
    const req: Request = authMockRequest({}, { username: USERNAME, password: '' }) as Request;
    const res: Response = authMockResponse();
    SignIn.prototype.read(req, res).catch((error: CustomError) => {
      expect(error.statusCode).toEqual(400);
      expect(error.serializeErrors().message).toContain('Password is a required field');
    });
  });

  it('should throw an error if password length is less than minimum length', () => {
    const req: Request = authMockRequest({}, { username: USERNAME, password: WRONG_PASSWORD }) as Request;
    const res: Response = authMockResponse();
    SignIn.prototype.read(req, res).catch((error: CustomError) => {
      expect(error.statusCode).toEqual(400);
      expect(error.serializeErrors().message).toContain('Password must be at least 8 characters');
    });
  });

  it('should throw an error if password length is greater than maximum length', () => {
    const req: Request = authMockRequest({}, { username: USERNAME, password: LONG_PASSWORD }) as Request;
    const res: Response = authMockResponse();
    SignIn.prototype.read(req, res).catch((error: CustomError) => {
      expect(error.statusCode).toEqual(400);
      expect(error.serializeErrors().message).toContain('Password must be no more than 128 characters');
    });
  });

  it('should throw "Invalid credentials" if username does not exist', () => {
    const req: Request = authMockRequest({}, { username: USERNAME, password: PASSWORD }) as Request;
    const res: Response = authMockResponse();
    jest.spyOn(authService, 'getAuthUserByUsername').mockResolvedValueOnce(null as any);

    SignIn.prototype.read(req, res).catch((error: CustomError) => {
      // Service receives original username and normalizes internally
      expect(authService.getAuthUserByUsername).toHaveBeenCalledWith(USERNAME);
      expect(error.statusCode).toEqual(400);
      expect(error.serializeErrors().message).toEqual('Invalid credentials');
    });
  });

  it('should throw "Invalid credentials" if password does not exist', () => {
    const req: Request = authMockRequest({}, { username: USERNAME, password: PASSWORD }) as Request;
    const res: Response = authMockResponse();
    jest.spyOn(authService, 'getAuthUserByUsername').mockResolvedValueOnce(null as any);

    SignIn.prototype.read(req, res).catch((error: CustomError) => {
      // Service receives original username and normalizes internally
      expect(authService.getAuthUserByUsername).toHaveBeenCalledWith(USERNAME);
      expect(error.statusCode).toEqual(400);
      expect(error.serializeErrors().message).toEqual('Invalid credentials');
    });
  });

  // section 9 video 247 fix will be needed.
  // it('should set session data for valid credentials and send correct json response', async () => {
  //   const req: Request = authMockRequest({}, { username: USERNAME, password: PASSWORD }) as Request;
  //   const res: Response = authMockResponse();
  //   authMock.comparePassword = () => Promise.resolve(true);
  //   jest.spyOn(authService, 'getAuthUserByUsername').mockResolvedValue(authMock);
  //   jest.spyOn(userService, 'getUserByAuthId').mockResolvedValue(signUpMockDate);

  //   await SignIn.prototype.read(req, res);
  //   expect(req.session?.jwt).toBeDefined();
  //   expect(res.status).toHaveBeenCalledWith(200);
  //   expect(res.json).toHaveBeenCalledWith({
  //     message: 'User login successfully',
  //     user: existingUser,
  //     token: req.session?.jwt
  //   });
  // });
});
